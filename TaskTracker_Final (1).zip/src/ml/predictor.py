import joblib
from pathlib import Path
MODEL = Path('models') / 'time_predictor.joblib'
import numpy as np
class Predictor:
    def __init__(self):
        if MODEL.exists():
            self.model = joblib.load(MODEL)
        else:
            self.model = None
    def predict(self, X):
        if self.model is None:
            arr = np.array(X, dtype=float)
            return (arr[:,0]*1.5 + arr[:,1]*0.5).tolist()
        return self.model.predict(X).tolist()
